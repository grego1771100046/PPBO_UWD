/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan;

/**
 *
 * @author ilckom
 */
import java.awt.*;
import javax.swing.*;
public class ExampleLabel extends JFrame {
    JLabel label1;
    FlowLayout fl;
    private PopupMenu Label1;
    public ExampleLabel(){
        Container b = getContentPane();
        label1 = new JLabel ("Praktikum GUI");
        b. add(label1);
        setLayout(new FlowLayout());
        setSize(300, 100);
        show();
    }
    public static  void main(String[] args){
        ExampleLabel a = new ExampleLabel();
    }
    }
    
   
